module.exports = member => {
    let username = member.user.username;
    member.sendMessage('Selamlar,Değerli **' + username + '** Discord Sunucumaza Hoşgeldin :kissing_heart:  :thinking: Keyifli Vakit Geçirmen Dileğiyle. Buda sunucumuzun sınırsız linki. :wink:');

};
