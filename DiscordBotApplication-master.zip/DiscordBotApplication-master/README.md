# DiscordBotApplication
Merhaba dostlarım ben Xawin.
Alt yapıyı hazırlanken çok zorlandım emeğe saygı olarak videoyu beğenin.
